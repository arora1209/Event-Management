class TeamSize:

    def __init__(self,game,gameObj):
        self.teamSize = game[gameObj.gameType]

    