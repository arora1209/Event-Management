class Formatter:
    def getFormattedOutput(self,gameObj, allTeams) -> dict:
        self.teamId = 1
        self.teamName = 'A'
        self.listOfteams=[]

        for teams in allTeams:
            teamDetail={
                    "id": self.teamId,
                    "name": 'Team-'+self.teamName,
                    "gameType": gameObj.gameType,
                    "players": teams 
                }
            self.teamId+=1
            self.teamName = chr(ord(self.teamName)+1)
            self.listOfteams.append(teamDetail)
    
        output= {'teams': self.listOfteams ,'total': len(allTeams) }
        return output