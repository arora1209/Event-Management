from abc import ABC,abstractmethod

class IEventActions:
    
    @abstractmethod
    def createTeam(self, data) -> dict:
        # raise NotImplementedError
        pass

    @abstractmethod
    def createFixture(self, data) -> str:
        # raise NotImplementedError
        pass