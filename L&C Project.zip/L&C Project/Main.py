from Server import Server

if __name__ == "__main__":

    server = Server()
    server.creating_socket_connection()
