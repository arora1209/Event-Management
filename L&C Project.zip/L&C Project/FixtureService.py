from Data_model.TeamList import Teamlist
from EventActions import IEventActions
from Fixture import Fixture
from FixtureJson import FixtureJson

class FixtureService(IEventActions):
    def createFixture(self, data) -> dict:
        fixture = Fixture(data)
        teamListObj = Teamlist(data)
        fixtureList = fixture.createFixture( teamListObj)
        fixtureJsonObj = FixtureJson()
        fixtureJson = fixtureJsonObj.createFixtureJson(teamListObj, fixtureList)
        return fixtureJson
