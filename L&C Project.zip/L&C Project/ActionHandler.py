import json
from TeamCreator import TeamCreator 
from Data_model.DatabaseConnection import DatabaseConnection
from Data_model.PlayerDetails import PlayerDetails
from Data_model.SaveFixture import SaveFixture
from Data_model.TeamDetails import TeamDetails
from Data_model.TeamPlayer import TeamPlayer
from FixtureService import FixtureService
from InputHandler import InputHandler
from client_server.ByteCalculator import ByteCalculator
from client_server.Encode import Encode
from client_server.JsonSerializer import JsonSerializer


class ActionHandler():
    def __init__(self):
        self.json_serializer = JsonSerializer()
        self.encode = Encode()
        self.byteCalculatorObj = ByteCalculator()
        self.db = DatabaseConnection()
        self.inputHandlerObj = InputHandler()
     
    def handleAction(self, connection,command , data) -> None:
        self.connection = connection
        self.data = data
        if command == 'create_team':
            self.handleCreateTeam()

        elif command == 'create_fixture':
            self.handlefixture()

    def handleCreateTeam(self) -> None:
        createTeamObj = TeamCreator (self.data)
        jsonDict = createTeamObj.createTeamDict()
        teamsStr = self.json_serializer.deserializeData(jsonDict)
        teamStrEncoded = self.encode.encodeStr(teamsStr)
        outputSize = str(self.byteCalculatorObj.getSize(teamStrEncoded))
        ### inserting into DB
        # playersDbObj = PlayerDetails()
        # playersDbObj.insertPlayerDetails(self.db, createTeamObj.gameObj)
        # teamsObj = TeamDetails()
        # teamsObj.insertTeamDetails(self.db,jsonDict)
        # teamPlayersObj = TeamPlayer()
        # teamPlayersObj.insertTeamPlayer(self.db, jsonDict)
        self.connection.sendall(outputSize.encode())
        self.connection.sendall(teamStrEncoded)

    def handlefixture(self) -> None:
        createFixtureObj = FixtureService()
        fixtureJson = createFixtureObj.createFixture(self.data)
        saveFixtureObj = SaveFixture()
        saveFixtureObj.insertFixtureDetails(self.db,fixtureJson,createFixtureObj)
        fixtureStr = json.dumps(fixtureJson)
        fixtureEncoded = self.encode.encodeStr(fixtureStr)
        outputSize = str(self.byteCalculatorObj.getSize(fixtureEncoded))
        self.connection.sendall(outputSize.encode())
        self.connection.sendall(fixtureEncoded)
