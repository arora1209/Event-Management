import random
import pandas as pd

class Teams:
    def createTeam(self, gameObj, teamSize) -> list:
        allTeams = []
        listOfPlayers=[]
        playerIDs = gameObj.players
        
        for player in playerIDs:
            listOfPlayers.append(player)

        random.shuffle(listOfPlayers)

        for players in range(0,len(listOfPlayers),teamSize):
            team = listOfPlayers[players:players+teamSize]
            allTeams.append(team)
        return allTeams


class TeamsData:
    def getTeamsData(self, db) -> pd.DataFrame.dtypes :
        query='''SELECT Team.teamId,Team.name,Team.gameId,Player.playerId, Player.playerName 
                 FROM Team 
                 INNER JOIN Team_Player 
                       ON Team.teamId = Team_Player.teamId 
                 INNER JOIN Player 
                       ON Team_Player.playerId = Player.playerId'''

        TeamTable = pd.read_sql(query, db.conn)

        return TeamTable
    
