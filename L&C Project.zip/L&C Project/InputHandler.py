from client_server.Encode import Encode
from client_server.JsonSerializer import JsonSerializer


class InputHandler():
    def __init__(self) -> None:
        self.json_serializer = JsonSerializer()
        self.encode = Encode()


    def handleHeader(self,connection) -> str:
        detailsEnc = connection.recv(1000)
        details= self.encode.decode(detailsEnc)
        detailsDict = self.json_serializer.serializeData(details)
        self.bytes = detailsDict['size']
        command = detailsDict['message']
        return command
    

    def handleData(self,connection) -> str:
        response_data = connection.recv(self.bytes)
        strData = self.encode.decode(response_data)
        return self.json_serializer.serializeData(strData)
        