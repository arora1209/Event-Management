from datetime import datetime, timedelta
from Data_model.FixturesData import FixturesData
from Data_model.GameRules import GameDuration, GameIds
from Matches import Matches

class Fixture:
    def __init__(self,data):
        self.matchesObj = Matches()
        self.fixtureData = FixturesData(data)

    def getFormattedDetails(self, teamListObj) -> None:
        date_format = "%d-%m-%Y %H:%M:%S"
        self.date_obj = datetime.strptime(self.fixtureData.startDateTime, date_format)
        self.date_end_obj = datetime.strptime(self.fixtureData.endDateTime, date_format)
        self.gameId = teamListObj.listOfTeams[0]['gameType']
        self.matchLength= self.getMatchLength()

    def getMatchLength(self) -> None:
        if self.gameId == GameIds.Cricket.value:
            return GameDuration.Cricket.value
        
        elif self.gameId == GameIds.Badminton.value:
            return GameDuration.Badminton.value
        
        elif self.gameId == GameIds.Chess.value:
            return GameDuration.Chess.value
        
        else: 
            raise Exception("game id is not valid")
    

    def getFixturesList(self) -> None:
        for match in (self.matches):
            game={}
            if self.startDatetime.date not in self.fixtureData.holidays:
                if (self.startDatetime + timedelta(minutes=self.matchLength)) < self.date_end_obj:
                    game={'Start':str(self.startDatetime),
                            'teams': match}
                    self.startDatetime=self.startDatetime+ timedelta(minutes=self.matchLength)

                else:
                    self.startDatetime=self.date_obj+ timedelta(days=1)
                    game={'Start':str(self.startDatetime),
                        'teams': match}
                    self.startDatetime = self.startDatetime+ timedelta(minutes= self.matchLength)

            self.fixtureList.append(game)


    def createFixture(self,teamListObj) -> list:
        self.getFormattedDetails(teamListObj)
        self.matches = self.matchesObj.setMatches(teamListObj.teamNames)
        self.fixtureList=[]
        self.startDatetime = self.date_obj
        self.getFixturesList()
        return self.fixtureList
