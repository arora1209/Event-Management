import json
class JsonReader:
    def readingJson(self, name) -> str:
        f = open (name, "r")
        self.data = json.loads(f.read())
        return self.data


