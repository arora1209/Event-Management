from Data_model.Game import Game
from Data_model.GameRules import GameTeamSize
from EventActions import IEventActions
from Formatter import Formatter
from TeamSize import TeamSize
from Teams import Teams
from Data_model.GameRules import GameTeamSize, GameIds


class TeamCreator (IEventActions):
    def __init__(self, data):
        self.gameObj = Game(data)
        self.team = Teams()
        self.formatterObj = Formatter()


    def createTeamDict(self) -> dict:
        teamSize = self.getTeamSize(self.gameObj.gameType)
        allTeams = self.team.createTeam(self.gameObj, teamSize)
        return  self.formatterObj.getFormattedOutput(self.gameObj, allTeams)
    

    def getTeamSize(self, gameId) -> int:
        if gameId == GameIds.Cricket.value:
            return GameTeamSize.Cricket.value
        
        elif gameId == GameIds.Badminton.value:
            return GameTeamSize.Badminton.value
        
        elif gameId == GameIds.Chess.value:
            return GameTeamSize.Chess.value
        
        else: 
            raise Exception("game id is not valid")

        

