class TeamDetails:
    def insertTeamDetails(self, db, jsonDict) -> None:
        teamDetails = jsonDict['teams']
        for team in teamDetails:

            query='''
                INSERT INTO Team(teamId, name ,gameId)
                VALUES(?,?,?)
                '''
            db.cursor.execute(query,(team['id'], team['name'],team['gameType']))
            db.cursor.commit()