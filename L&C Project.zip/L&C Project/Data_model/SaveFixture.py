class SaveFixture:
    def insertFixtureDetails(self, db, fixture, createFixtureObj) -> None:
        gameType = fixture['gameId']
        duration =30
        if gameType ==1:
            duration=180
       
        for match in fixture['matches']:
            firstTeamName= match['teams'][0]
            secondTeamName= match['teams'][1]
            query='''
                INSERT INTO Matches(date,firstTeamName,secondTeamName, duration )
                VALUES(?,?,?,?)
                '''
            db.cursor.execute(query,(match['Start'], firstTeamName,secondTeamName,duration))
            db.cursor.commit()