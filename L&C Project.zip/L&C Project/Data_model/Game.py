class Game:
    def __init__(self, jsonObject):
        self.gameType = jsonObject['gameType']
        self.players = jsonObject['players']