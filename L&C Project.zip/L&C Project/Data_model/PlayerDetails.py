class PlayerDetails:
    def insertPlayerDetails(self, db, gameObj) -> None:
        for player in gameObj.players:
            query='''
                INSERT INTO Player(playerId, playerName)
                VALUES(?,?)
                '''
            db.cursor.execute(query,(player['playerId'], player['name']))
            db.cursor.commit()
