import pandas as pd
class Dbtables:
    def getTable(self,db, tableName) -> pd.DataFrame.dtypes:
        self.query = 'SELECT  * FROM '+ tableName
        self.Table = pd.read_sql(self.query, db.conn)

        return self.Table