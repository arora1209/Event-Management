class FixturesData:
    def __init__(self, data):
        self.holidays=[]
        holidayList= data['holidayList']
        for day in holidayList:
            self.holidays.append(day['date'])
        eventDict = data['event']
        self.startDate =eventDict['startDate']
        self.endDate =eventDict['endDate']
        self.dayStart = '09:00:00'
        self.dayEnd = '17:00:00'
        self.startDateTime = self.startDate+ ' '+self.dayStart
        self.endDateTime= self.startDate+ ' '+self.dayEnd
       
   