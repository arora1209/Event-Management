class Teamlist:
    def __init__(self, data):
        self.listOfTeams = data['listOfTeams']['teams']
        self.teamNames = []
        for i in self.listOfTeams:
            self.teamNames.append(i['name'])
        