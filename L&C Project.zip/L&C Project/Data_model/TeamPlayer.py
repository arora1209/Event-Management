class TeamPlayer:
    def insertTeamPlayer(self, db, jsonDict) -> None:
        teamsData = jsonDict['teams']
        for teams in teamsData :
            players = teams['players']
            for j in players:
                playerId = j['playerId']
                query='''
                    INSERT INTO Team_Player( playerId ,teamId)
                    VALUES(?,?)
                    '''
                db.cursor.execute(query,(playerId, teams['id']))
                db.cursor.commit()