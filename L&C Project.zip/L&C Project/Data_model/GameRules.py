from enum import Enum

class GameIds(Enum):
    Cricket = 1
    Badminton = 2
    Chess = 3

class GameTeamSize(Enum):
    Cricket = 11
    Badminton = 2
    Chess = 1

class GameDuration(Enum):
    Cricket = 180
    Badminton = 30
    Chess = 30