import pyodbc 

class DatabaseConnection:
    def __init__(self):
        conn_str = (
        r'DRIVER={SQL Server};'
        r'SERVER=ITT-ARPITA;'
        r'DATABASE=L&C_Workshop;'
        r'Trusted_Connection=yes;'
        )

        self.conn = pyodbc.connect(conn_str)
        self.cursor = self.conn.cursor()
