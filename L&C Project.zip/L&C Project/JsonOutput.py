import json
class JsonOutput:
    def __init__(self, name ,jsonDict):
        with open(name, "w") as file:
            json.dump(jsonDict, file,indent=4)
