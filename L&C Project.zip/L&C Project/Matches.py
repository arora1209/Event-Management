class Matches:
    def setMatches(self, teams) -> list:
        if len(teams) % 2 != 0:
            teams.append("BYE")

        fixtures = []
        for index in range(len(teams) // 2):
            fixtures.append((teams[index], teams[len(teams) - 1 - index]))
        return fixtures