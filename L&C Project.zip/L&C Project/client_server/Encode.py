class Encode():
    def encodeStr(self,strData) -> bytes:
        return strData.encode()

    def decode(self, dataBytes) -> str:
        return dataBytes.decode('utf-8')