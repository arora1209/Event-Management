from communicationProtocol import communicationProtocol
from FileReader import FileReader
from JsonObject import JsonObject
from Encode import Encode
from JsonSerializer import JsonSerializer


class ISCrequest(communicationProtocol) :

    def __init__(self):
        self.file_reader = FileReader()
        self.json_object = JsonObject()
        self.encode = Encode()
        self.json_serializer = JsonSerializer()
    
  
    def setMessageDetails(self,communicationProtocol)->dict :
        communicationProtocol.details["portNumber"] = communicationProtocol.portNumber
        communicationProtocol.details["message"]=  communicationProtocol.message
        communicationProtocol.details["size"]=communicationProtocol.size
        return communicationProtocol.details
    


    def setRequestInput(self,inputLocation) ->bytes :
        file = self.file_reader.readFile(inputLocation)
        jsonData = self.json_object.createJsonObject(file)
        strData = self.json_serializer.deserializeData(jsonData)
        encodedData = self.encode.encodeStr(strData)
        return encodedData



class ISCresponse(communicationProtocol):
    def getResponse(self, socket)->str:
        recvBytes = int((socket.recv(10000)).decode('utf-8'))
        return (socket.recv(recvBytes)).decode('utf-8')
    
    