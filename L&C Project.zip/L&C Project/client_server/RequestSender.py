class RequestSender:
   
    def sendRequest(self,data,socket ) -> None:
        socket.sendall(data)