import socket

class SocketConnection:
    def createSocketConnection(self, host,portNumber) -> socket :
        print('hello')
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print(portNumber)
        sock.connect((host, portNumber ))
        return sock