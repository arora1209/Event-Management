class UserInput:
    def getUserInput(self) -> str:
        print ('enter you command ("press q to exit"): ')
        return input()
    