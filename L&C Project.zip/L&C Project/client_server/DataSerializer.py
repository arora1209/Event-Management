from abc import ABC,abstractmethod

class IDataSerializer:

    @abstractmethod
    def serializeData(self, data) -> dict:
        # raise NotImplementedError
        pass

    @abstractmethod
    def deserializeData(self, data) -> str:
        # raise NotImplementedError
        pass