import json
import sys
sys.path.insert(0, 'C:/Users/arpit.arora/Desktop/L&C Project/client_server')
from DataSerializer import IDataSerializer

class JsonSerializer(IDataSerializer):
    def serializeData(self, data) ->dict :
        return json.loads(data)

    def deserializeData(self, data) -> str:
        strData = json.dumps(data)
        return strData
    