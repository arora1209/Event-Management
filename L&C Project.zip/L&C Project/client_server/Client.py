from communicationProtocol import communicationProtocol
from ClientOperation import Clientoperation
from SocketConnection import SocketConnection 

class client:

    def setConnection(self): 
        try:
            communicationProtocolObj = communicationProtocol()
            self.host = '127.0.0.1' 
            self.portNumber = 5005
            communicationProtocolObj.portNumber  = self.portNumber
            socketConnectionObj = SocketConnection()
            socket = socketConnectionObj.createSocketConnection(self.host, self.portNumber)
            print('Client connected.')
            clientOperation = Clientoperation()
            clientOperation.operation(communicationProtocolObj, socket)
           
        except Exception as e:
            print('unable to connect to server', e)

client = client()
client.setConnection()
