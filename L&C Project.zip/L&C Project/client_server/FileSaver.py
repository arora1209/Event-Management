import json
class FileSaver:
    def saveFile(self,data ,location) -> None:
        with open(location, "w") as file:
            json.dump(data, file,indent=4)
            print('file saved at abcd:- ',location)