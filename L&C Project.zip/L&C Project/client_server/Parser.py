class Parser:
    def getParametersFromCommand(self,command) -> dict:
        parametersDict = {}
        parametersDict['header'] = command.split(' ')[0]
        parametersDict['message'] = command.split(' ')[2]
        parametersDict['input_location'] = command.split(' ')[4].replace("'",'')
        parametersDict['output_loaction'] = command.split(' ')[6].replace("'",'')
        return parametersDict