import json

class JsonObject:
    @staticmethod
    def createJsonObject(file) -> dict:
        jsonData = json.loads(file.read())
        return jsonData