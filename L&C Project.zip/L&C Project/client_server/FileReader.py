from typing import TextIO

class FileReader:
    def readFile(self, inputPath) -> TextIO:
        return open (inputPath, "r")