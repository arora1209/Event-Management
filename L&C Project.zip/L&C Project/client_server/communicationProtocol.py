import sys
sys.path.insert(0, 'C:/Users/arpit.arora/Desktop/L&C Project/client_server')
from ByteCalculator import ByteCalculator

class communicationProtocol:
    data = ''
    portNumber=''
    message = ''
    size =0
    details={}

    def setValues(self,encodedData,message) -> None:
        self.ByteCalculatorObj = ByteCalculator()
        self.data = encodedData  
        self.size =self.ByteCalculatorObj.getSize(self.data)
        self.message = message