from Parser import Parser
from JsonSerializer import JsonSerializer
from Encode import Encode
from ISCrequest import ISCrequest,ISCresponse
from FileSaver import FileSaver
from RequestSender import RequestSender
from UserInput import UserInput
from FileSaver import FileSaver
from Header import Header

class Clientoperation:
    def __init__(self):
        self.parser = Parser()
        self.json_serializer = JsonSerializer()
        self.encode = Encode()
        self.isc_request = ISCrequest()
        self.userInputObj = UserInput()
        self.fileSaverObj = FileSaver()
        self.isc_respose = ISCresponse()
        self.headerObj = Header()
        self.requestSenderObj = RequestSender()

    def checkCommand(self, header)-> bool:
        return (header == 'isc')

    def operation(self, communicationProtocol, socket) -> None:
        while True:
            user_input = self.userInputObj.getUserInput()
            if user_input =='q':  
                break

            parametersDict = self.parser.getParametersFromCommand(user_input)
            
            if self.checkCommand(parametersDict['header']):
                encodedData = self.isc_request.setRequestInput(parametersDict['input_location'])
                communicationProtocol.setValues(encodedData,parametersDict['message'])
                encodedHeader = self.headerObj.getHeader(communicationProtocol)
                self.requestSenderObj.sendRequest(encodedHeader, socket)
                self.requestSenderObj.sendRequest(encodedData, socket)
                responseStr = self.isc_respose.getResponse(socket)
                jsonResponse = self.json_serializer.serializeData(responseStr)
                self.fileSaverObj.saveFile(jsonResponse,parametersDict['output_loaction'])

            else: 
                print('Enter valid command')

            

    