from Encode import Encode
from ISCrequest import ISCrequest
from JsonSerializer import JsonSerializer

class Header:
    def __init__(self):
        self.isc_request = ISCrequest()
        self.json_serializer = JsonSerializer()
        self.encode = Encode()

    def getHeader(self, communicationProtocol) -> bytes:
        headerDict =self.isc_request.setMessageDetails(communicationProtocol)
        headerDictStr= self.json_serializer.deserializeData(headerDict)
        return self.encode.encodeStr(headerDictStr)

    