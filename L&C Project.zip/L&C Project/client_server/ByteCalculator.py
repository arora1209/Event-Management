import sys

class ByteCalculator:
    def getSize(self,EncodedData) ->int :
      return sys.getsizeof(EncodedData)