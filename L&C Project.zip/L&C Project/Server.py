import socket
from client_server.communicationProtocol import communicationProtocol
from InputHandler import InputHandler
from ActionHandler import ActionHandler

class Server:

    def __init__(self):
        self.inputHandlerObj = InputHandler()
        self.actionhandlerObj = ActionHandler()

    def creating_socket_connection(self) -> None:
        try:
            HOST = '127.0.0.1'
            PORT = 5005
            self.new_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.new_socket.bind((HOST, PORT))
            self.new_socket.listen(1)
            self.connection, socket_address = self.new_socket.accept()
            print('Client connected: ', socket_address)
        except:
            print("Connection failed")

    def interactive_with_client(self) -> None:
        while True:
            command= self.inputHandlerObj.handleHeader(self.connection)
            data = self.inputHandlerObj.handleData(self.connection)
            self.actionhandlerObj.handleAction(self.connection ,command, data)
            

server = Server()
communicationProtocol = communicationProtocol()
server.creating_socket_connection()
server.interactive_with_client()
