class FixtureJson:
    def createFixtureJson(self, teamListObj,fixtureList) -> dict:
        fixtureJson = { "gameId": teamListObj.listOfTeams[0]['gameType'],
                        "matches": fixtureList}
        
        return fixtureJson