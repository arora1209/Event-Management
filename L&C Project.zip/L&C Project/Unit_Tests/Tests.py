import unittest
import sys
import json

sys.path.insert(0, 'C:/Users/arpit.arora/Desktop/L&C Project/')

from FixtureService import FixtureService
from TeamCreator import CreateTeamWrapper
from client_server.FileReader import FileReader
from client_server.JsonObject import JsonObject
from client_server.JsonSerializer import JsonSerializer

class Tests(unittest.TestCase):
    def test_createTeamWithCorrectData(self) -> None:
        filePath ='C:/Users/arpit.arora/Desktop/L&C Project/client_server/TeamsInputJSON.json'
        fileReaderObj = FileReader()
        print("inside test")
        file = fileReaderObj.readFile(filePath)
        json_object = JsonObject()
        jsonData = json_object.createJsonObject(file)
        createTeamObj = CreateTeamWrapper(jsonData)
        jsonDict = createTeamObj.createTeamDict()
        # json_serializer = JsonSerializer()
        teamsStr = json.dumps(jsonDict)
        print('teamsStr:',teamsStr)
        expectedOutput = '{"teams": [{"id": 1, "name": "Team-A", "gameType": 2, "players": [{"playerId": 1, "name": "A"}, {"playerId": 4, "name": "D"}]}, {"id": 2, "name": "Team-B", "gameType": 2, "players": [{"playerId": 2, "name": "B"}, {"playerId": 3, "name": "C"}]}], "total": 2}'
        print("expectedOutput: ", expectedOutput )
        self.assertEqual(teamsStr, expectedOutput)


if __name__ == '__main__':
    unittest.main()

